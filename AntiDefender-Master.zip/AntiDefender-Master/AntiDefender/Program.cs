﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace AntiDefender
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "AntiDefender";

            menu();

        }

        static void menu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔═══╗╔═╗─╔╗╔════╗╔══╗╔═══╗╔═══╗╔═══╗╔═══╗╔═╗─╔╗╔═══╗╔═══╗╔═══╗");
            Thread.Sleep(800);
            Console.WriteLine("║╔═╗║║║╚╗║║║╔╗╔╗║╚╣─╝╚╗╔╗║║╔══╝║╔══╝║╔══╝║║╚╗║║╚╗╔╗║║╔══╝║╔═╗║");
            Thread.Sleep(800);
            Console.WriteLine("║║─║║║╔╗╚╝║╚╝║║╚╝─║║──║║║║║╚══╗║╚══╗║╚══╗║╔╗╚╝║─║║║║║╚══╗║╚═╝║");
            Thread.Sleep(800);
            Console.WriteLine("║╚═╝║║║╚╗║║──║║───║║──║║║║║╔══╝║╔══╝║╔══╝║║╚╗║║─║║║║║╔══╝║╔╗╔╝");
            Thread.Sleep(800);
            Console.WriteLine("║╔═╗║║║─║║║──║║──╔╣─╗╔╝╚╝║║╚══╗║║───║╚══╗║║─║║║╔╝╚╝║║╚══╗║║║╚╗");
            Thread.Sleep(800);
            Console.WriteLine("╚╝─╚╝╚╝─╚═╝──╚╝──╚══╝╚═══╝╚═══╝╚╝───╚═══╝╚╝─╚═╝╚═══╝╚═══╝╚╝╚═╝");
            Thread.Sleep(2000);
            Console.WriteLine("Disable: Disable Windows Defender");
            Console.WriteLine("Enable: Enable Windows Defender");

            string choice = Console.ReadLine();
            switch (choice.ToLower())
            {
                case "disable":
                    {
                        if (Registry.GetValue(
                                @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection",
                                "DisableRealtimeMonitoring", null) == null)
                        {
                            Registry.LocalMachine.CreateSubKey(
                                @"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection");
                            Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender",
                                "DisableAntiSpyware", "1", RegistryValueKind.DWord);
                            Registry.SetValue(
                                @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection",
                                "DisableRealtimeMonitoring", "1", RegistryValueKind.DWord);

                            Console.WriteLine(
                                "Windows Defender disabled! Restart to take action\n");


                            Console.WriteLine("Would you like to restart now? (y/n)");
                            string input2 = Console.ReadLine();
                            if (input2.ToLower().Contains("y"))
                            {
                                Process.Start("shutdown",
                                    "/r /t 0");
                                Console.Read();
                            }
                            else if (input2.ToLower().Contains("n"))
                            {

                            }
                            else
                            {
                                Console.WriteLine("Invalid choice");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Already Disabled");
                        }

                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue");
                        Console.ReadKey();
                        Console.Clear();
                        menu();
                        break;
                    }
                case "enable":
                    {
                        try
                        {
                            string keyName =
                                @"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection";
                            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyName, true))
                            {
                                key?.DeleteValue("DisableRealtimeMonitoring");
                            }

                            string keyName2 =
                                @"SOFTWARE\Policies\Microsoft\Windows Defender";
                            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyName2, true))
                            {
                                key?.DeleteValue("DisableAntiSpyware");
                            }
                        }
                        catch (ArgumentException e)
                        {
                            //Console.WriteLine(e.Message + "\n");
                            Console.WriteLine("Already enabled");
                        }


                        Console.WriteLine("Would you like to restart now ? (y/n)");
                        string input2 = Console.ReadLine();
                        if (input2.ToLower().Contains("y"))
                        {
                            Process.Start("shutdown",
                                "/r /t 0");
                            Console.Read();
                        }
                        else if (input2.ToLower().Contains("n"))
                        {

                        }
                        else
                        {
                            Console.WriteLine("Invalid choice");
                        }



                        Console.WriteLine();
                        Console.WriteLine("Press any key to continue");
                        Console.ReadKey();
                        Console.Clear();
                        menu();
                        break;

                    }
                default:
                    {
                        menu();
                        return;
                    }
            }


        }

    }
}